class UserLibs():
    def __init__(self, id=0, name=None, doj=None, email=None, password=None):
        """
        Constructor for the UserLibs class.

        Args:
            id (int): User ID.
            name (str): User name.
            doj (str): Date of joining.
            email (str): User email.
            password (str): User password.
        """
        self.id = id
        self.email = email
        self.password = password
        self.name = name
        self.doj = doj

    def getId(self):
        """
        Get the user ID.

        Returns:
            int: User ID.
        """
        return self.id
    
    def getName(self):
        """
        Get the user name.

        Returns:
            str: User name.
        """
        return self.name

    def getEmail(self):
        """
        Get the user email.

        Returns:
            str: User email.
        """
        return self.email

    def getPassword(self):
        """
        Get the user password.

        Returns:
            str: User password.
        """
        return self.password
    
    def getDoj(self):
        """
        Get the date of joining.

        Returns:
            str: Date of joining.
        """
        return self.doj

    def setId(self, id):
        """
        Set the user ID.

        Args:
            id (int): User ID.
        """
        self.id = id

    def setName(self, name):
        """
        Set the user name.

        Args:
            name (str): User name.
        """
        self.name = name

    def setEmail(self, email):
        """
        Set the user email.

        Args:
            email (str): User email.
        """
        self.email = email

    def setPassword(self, password):
        """
        Set the user password.

        Args:
            password (str): User password.
        """
        self.password = password

    def setDoj(self, doj):
        """
        Set the date of joining.

        Args:
            doj (str): Date of joining.
        """
        self.doj = doj

    def __str__(self):
        """
        Get a string representation of the UserLibs object.

        Returns:
            str: String representation of the UserLibs object.
        """
        return '{},{},{},{},{}'.format(self.id, self.name, self.doj, self.email, self.password)