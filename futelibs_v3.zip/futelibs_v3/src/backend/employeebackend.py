from backend.database import *
import sys


'''make new issues functions'''

def Get_customer_table_data():
    """
    Retrieves data from the customer table in the database.

    Returns:
        result (list): A list of tuples containing the mid and name of each member.
    """
    conn = None

    sql = 'select mid, name from members'
    result = None
    try:
        conn = Connect()
        cursor = conn.cursor()
        cursor.execute(sql)
        result = cursor.fetchall()
        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del sql, conn
        return result
    



def Get_book_table_data():
    """
    Retrieves book data from the database table.
    
    Returns:
    - A list of tuples containing the book ID, name, and author.
    """

    conn = None  # Connection object
    
    sql = 'select bid, name, author from book where holder = 0'  # SQL query to retrieve book data
    result = None  # Variable to store the query result
    
    try:
        conn = Connect()  # Establish a database connection
        cursor = conn.cursor()  # Create a cursor object
        cursor.execute(sql)  # Execute the SQL query
        result = cursor.fetchall()  # Fetch all rows from the query result
        cursor.close()  # Close the cursor
        conn.close()  # Close the connection

    except:
        print('Error', sys.exc_info())  # Print any errors that occur

    finally:
        del sql, conn  # Clean up variables
        return result  # Return the query result


    
def check_mid(mid):
    """
    Check if a member exists in the database and return their ID and name.

    Args:
        mid (int): The ID of the member to check.

    Returns:
        tuple: A tuple containing the ID and name of the member, or None if the member doesn't exist.
    """
    conn = None

    # SQL query to select the member with the given ID
    sql = 'SELECT mid, name FROM members WHERE mid = %s'
    values = (mid,)
    result = None

    try:
        conn = Connect()
        cursor = conn.cursor()

        # Execute the SQL query with the given ID
        cursor.execute(sql, values)

        # Fetch the first row from the query result
        result = cursor.fetchone()

        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn

        # Return the result of the query
        return result


def check_bid(bid):
    """
    Function to check if a book exists in the database with the given bid and is not currently held by anyone.

    Args:
        bid (int): The book ID to check.

    Returns:
        tuple: A tuple containing the book ID, name, and author if the book exists and is not held by anyone. 
               None otherwise.
    """
    conn = None

    # SQL query to fetch the book details with the given bid and not held by anyone
    sql = 'SELECT bid, name, author FROM book WHERE bid=%s AND holder=0'
    values = (bid,)
    result = None
    try:
        conn = Connect()
        cursor = conn.cursor()
        cursor.execute(sql, values)
        result = cursor.fetchone()
        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn
        return result



def make_new_issue(mid, bid, eid):
    """
    Function to make a new issue in the library system.

    Args:
        mid (int): Member ID.
        bid (int): Book ID.
        eid (int): Employee ID.
    """

    conn = None

    # SQL query to update the holder of the book
    sql1 = 'update book set holder=%s where bid=%s'
    values1 = (mid, bid)

    # Get the next transaction ID
    tid = maxi()
    tid = tid[3]
    tid = tid + 1
    tid = str(tid)

    # SQL query to insert a new transaction
    sql2 = "insert into raw_tr values(%s,%s,%s,%s,CURDATE(),'pending',NULL,NULL)"
    values2 = (tid, mid, bid, eid)

    try:
        conn = Connect()
        cursor = conn.cursor()

        # Execute the first SQL query
        cursor.execute(sql1, values1)

        # Execute the second SQL query
        cursor.execute(sql2, values2)

        # Commit the changes to the database
        conn.commit()

        # Close the cursor and connection
        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        # Clean up variables
        del values1, values2, sql1, sql2, conn


'''return issue functions'''

def Get_issue_table_data(mid):
    '''
    Get the issue table data for a given mid.

    Args:
        mid (int): The mid value.

    Returns:
        list: A list of tuples containing the tid, bid, name, and fine_payable.
    '''

    conn = None

    # SQL query to select the required data
    sql = 'select raw_tr.tid, raw_tr.bid, pending_v.name, pending_v.fine_payable from raw_tr, pending_v where raw_tr.mid=%s and raw_tr.tid=pending_v.tid'
    values = (mid,)

    result = None
    try:
        # Establish a database connection
        conn = Connect()

        # Create a cursor object
        cursor = conn.cursor()

        # Execute the SQL query with the given values
        cursor.execute(sql, values)

        # Fetch all the rows returned from the query
        result = cursor.fetchall()

        # Close the cursor and connection
        cursor.close()
        conn.close()

    except:
        # Print the error details if an exception occurs
        print('Error', sys.exc_info())

    finally:
        # Clean up resources and return the result
        del sql, conn, values
        return result


def check_tid(tid):
    """
    Function to check the tid in the database and return the bid and fine payable.

    Args:
        tid (int): The transaction id to be checked.

    Returns:
        tuple: A tuple containing the bid and fine payable.
    """
    conn = None

    # SQL query to select the bid and fine payable from the raw_tr and pending_v tables
    sql = 'select raw_tr.bid, pending_v.fine_payable from raw_tr, pending_v where raw_tr.tid = pending_v.tid and raw_tr.tid = %s'
    values = (tid,)
    result = None

    try:
        conn = Connect()
        cursor = conn.cursor()
        cursor.execute(sql, values)
        result = cursor.fetchone()
        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn
        return result




def make_return_issue(bid, tid, fine):
    """
    Update the book and raw_tr tables to mark a book as returned and update the transaction details.
    
    Args:
        bid (int): The book ID.
        tid (int): The transaction ID.
        fine (float): The fine amount.
    """
    conn = None

    # Update the book table to mark the book as returned
    sql1 = 'UPDATE book SET holder = 0 WHERE bid = %s'
    values1 = (bid,)

    # Update the raw_tr table to mark the transaction as returned
    sql2 = "UPDATE raw_tr SET status = 'returned' WHERE tid = %s"
    values2 = (tid,)

    # Update the raw_tr table to set the return date
    sql3 = "UPDATE raw_tr SET re_date = CURDATE() WHERE tid = %s"
    values3 = (tid,)

    # Update the raw_tr table to set the fine amount paid
    sql4 = "UPDATE raw_tr SET fine_paid = %s WHERE tid = %s"
    values4 = (fine, tid)

    try:
        conn = Connect()
        cursor = conn.cursor()

        # Execute the SQL queries
        cursor.execute(sql1, values1)
        cursor.execute(sql2, values2)
        cursor.execute(sql3, values3)
        cursor.execute(sql4, values4)

        # Commit the changes to the database
        conn.commit()

    except:
        print('Error', sys.exc_info())

    finally:
        # Cleanup resources
        cursor.close()
        conn.close()

        # Cleanup variables
        del values1, values2, values3, values4, sql1, sql2, sql3, sql4, conn