import mysql.connector
import sys


def Connect():
    """
    Connects to a MySQL database.

    Returns:
        conn (mysql.connector.connection.MySQLConnection): Connection object to the MySQL database.
    """
    conn = None
    try:
        conn = mysql.connector.Connect(
            host='localhost',
            user='root',
            passwd='root',
            database='futelibs'
        )
    except:
        print('Error', sys.exc_info())
    finally:
        return conn
    

def maxi():
    """
    Retrieves the first row from the 'maxi' table in the database.

    Returns:
        result (tuple or None): The first row from the 'maxi' table, or None if an error occurred.
    """
    conn = None
    sql = 'select * from maxi'
    result = None
    try:
        conn = Connect()
        cursor = conn.cursor()
        cursor.execute(sql)
        result = cursor.fetchone()
        cursor.close()
        conn.close()
    except:
        print('Error', sys.exc_info())
    finally:
        del sql, conn
        return result