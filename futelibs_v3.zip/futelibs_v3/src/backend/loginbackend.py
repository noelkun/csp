from backend.database import Connect
import sys


def login(user_ent_dat, user):
    """
    Function to perform user login.

    Args:
        user_ent_dat: UserEntity object containing email and password.
        user: String indicating the type of user (admin, employee, member).

    Returns:
        Tuple containing the user information if login is successful, None otherwise.
    """
    conn = None

    if user == 'admin':
        sql = """SELECT * FROM admin WHERE email=%s AND pass=%s"""
    elif user == 'employee':
        sql = """SELECT * FROM employee WHERE email=%s AND pass=%s"""
    elif user == 'member':
        sql = """SELECT * FROM members WHERE email=%s AND pass=%s"""

    values = (user_ent_dat.getEmail(), user_ent_dat.getPassword())
    result = None
    try:
        conn = Connect()
        cursor = conn.cursor()
        cursor.execute(sql, values)
        result = cursor.fetchone()
        cursor.close()
        conn.close()

    except:
        print('Error', sys.exc_info())

    finally:
        del values, sql, conn
        return result