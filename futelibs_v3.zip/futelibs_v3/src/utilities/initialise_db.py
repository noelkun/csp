import mysql.connector
import sys


def Connect():
    """
    Connects to the MySQL database.

    Returns:
        mysql.connector.connection.MySQLConnection: The database connection object.
    """
    conn = None
    try:
        conn = mysql.connector.Connect(
            host='localhost',
            user='root',
            passwd='root',
            database='futelibs'
        )
    except:
        print('Error', sys.exc_info())
    finally:
        return conn


def create_db():
    """
    Creates the database and necessary tables/views in the database.
    Inserts initial data into the tables.
    """

    conn = None

    # Database creation queries
    sql0 = """DROP DATABASE IF EXISTS futelibs"""
    sql1 = """CREATE DATABASE futelibs"""
    sql2 = """USE futelibs"""
    sql3 = """CREATE TABLE admin (
                    aid INT PRIMARY KEY,
                    name VARCHAR(50),
                    doj DATE,
                    email VARCHAR(50),
                    pass VARCHAR(20)
                )"""
    
    sql4 = """CREATE TABLE employee (
                    eid INT PRIMARY KEY,
                    name VARCHAR(50),
                    doj DATE,
                    email VARCHAR(50),
                    pass VARCHAR(20)
                )"""
    
    sql5 = """CREATE TABLE members (
                    mid INT PRIMARY KEY,
                    name VARCHAR(50),
                    doj DATE,
                    email VARCHAR(50),
                    pass VARCHAR(20)
                )"""
    
    sql6 = """CREATE TABLE book (
                    bid INT PRIMARY KEY,
                    name VARCHAR(50),
                    author VARCHAR(50),
                    holder INT
                )"""
    
    sql7 = """CREATE TABLE raw_tr (
                    tid INT PRIMARY KEY,
                    mid INT,
                    bid INT,
                    eid INT,
                    issue_date DATE,
                    status VARCHAR(10),
                    re_date DATE,
                    fine_paid INT
                )"""

    sql8 = """CREATE VIEW tran_v AS
                (SELECT tid,
                        mid,
                        bid,
                        eid,
                        issue_date,
                        status,
                        DATE_ADD(issue_date, INTERVAL 10 DAY) AS exp_re_date,
                        IF(status = 'pending',
                            IF(DATEDIFF(DATE_ADD(issue_date, INTERVAL 10 DAY), CURDATE()) < 0,
                                'delayed',
                                DATEDIFF(DATE_ADD(issue_date, INTERVAL 10 DAY), CURDATE())
                            ),
                            'returned'
                        ) AS days_left,
                        IF(status = 'pending',
                            IF(DATEDIFF(DATE_ADD(issue_date, INTERVAL 10 DAY), CURDATE()) < 0,
                                (-1) * DATEDIFF(DATE_ADD(issue_date, INTERVAL 10 DAY), CURDATE()),
                                0
                            ),
                            IF(re_date > DATE_ADD(issue_date, INTERVAL 10 DAY),
                                (-1) * DATEDIFF(DATE_ADD(issue_date, INTERVAL 10 DAY), re_date),
                                0
                            )
                        ) AS delay,
                        IF(DATEDIFF(DATE_ADD(issue_date, INTERVAL 10 DAY), CURDATE()) < 0 AND status = 'pending',
                            (-10) * DATEDIFF(DATE_ADD(issue_date, INTERVAL 10 DAY), CURDATE()),
                            0
                        ) AS fine_payable,
                        fine_paid,
                        re_date
                FROM raw_tr)"""
    
    sql9 = """CREATE VIEW pending_v AS
                (SELECT tran_v.mid AS mid,
                        tran_v.tid,
                        tran_v.issue_date,
                        book.name,
                        tran_v.days_left,
                        tran_v.delay,
                        tran_v.fine_payable
                FROM tran_v, book
                WHERE book.bid = tran_v.bid
                    AND status = 'pending')"""
    
    sql10 = """CREATE VIEW returned_v AS
                (SELECT tran_v.mid AS mid,
                        tran_v.tid,
                        tran_v.issue_date,
                        book.name,
                        tran_v.re_date,
                        tran_v.delay,
                        tran_v.fine_paid
                FROM tran_v, book
                WHERE book.bid = tran_v.bid
                    AND status = 'returned')"""
    
    sql11 = """
    create view maxi as (
        select 
            max(admin.aid) as aid,
            max(members.mid) as mid,
            max(employee.eid) as eid,
            max(raw_tr.tid) as tid,
            max(book.bid) as bid
        from 
            admin, employee, members, raw_tr, book
    )
    """   
    # insertion queries for members, employee, admin, book, and raw_tr tables
    sql12 = """insert into members values(130,'Shyu',curdate() ,'user@outlook.com','pass')"""
    sql13 = """insert into employee values(102,'Nao',curdate(),'emp@outlook.com','pass')"""
    sql14 = """insert into admin values(101,'ALAM',curdate(),'admin@outlook.com','pass')"""
    sql15 = """insert into book values(111,'Alice in Wonderland','Lewis Carrol',130),(112,'Harry Potter and the Philosopher''s Stone',' J. K. Rowling',0),(113,'Harry Potter and the Chamber of Secrets',' J. K. Rowling',0),(114,'Harry Potter and the Prisoner of Azkaban',' J. K. Rowling',0),(115,'Harry Potter and the Goblet of Fire',' J. K. Rowling',0),(116,'Harry Potter and the Order of the Phoenix',' J. K. Rowling',0),(117,'Harry Potter and the Half-Blood Prince',' J. K. Rowling',0),(118,'Harry Potter and the Deathly Hallows',' J. K. Rowling',0),(119,'The Adventures of Tom Sawyer','Mark Twain',0),(120,'Gulliver’s Travels','Jonathan Swift',130),(121,'Robinson Crusoe','Daniel Defoe',0),(122,'Around the World in Eighty Days','Jules Verne',0),(123,'Moby Dick','Herman Melville',0),(124,'David Copperfield','Charles Dickens',0)"""
    sql16 = """insert into raw_tr values(1, 130, 111, 102, '20230926', 'returned', '20231010', 40),(2, 130, 117, 102, '20231005', 'returned', '20231006', 0),(3, 130, 121, 102, '20230930', 'returned', '20231022', 120),(4, 130, 123, 102, '20231010', 'returned', '20231024', 40),(5, 130, 120, 102, '20231021','pending', NULL, NULL),(6, 130, 111, 102, '20231024','pending', NULL, NULL)"""


    try:
        # Establish a connection to the database
        conn = Connect()
        cursor = conn.cursor()

        # Execute SQL queries
        cursor.execute(sql0)
        cursor.execute(sql1)
        cursor.execute(sql2)
        cursor.execute(sql3)
        cursor.execute(sql4)
        cursor.execute(sql5)
        cursor.execute(sql6)
        cursor.execute(sql7)
        cursor.execute(sql8)
        cursor.execute(sql9)
        cursor.execute(sql10)
        cursor.execute(sql11)
        cursor.execute(sql12)
        cursor.execute(sql13)
        cursor.execute(sql14)
        cursor.execute(sql15)
        cursor.execute(sql16)
        
        # Commit the changes to the database
        conn.commit()

        # Close the cursor and connection
        cursor.close()
        conn.close()

    except:
        # Print error information if an exception occurs
        print('Error', sys.exc_info())
        print('DATABASE INITIALISATION FAILED')

    finally:
        # Clean up variables
        del conn, sql0, sql1, sql2, sql3, sql4, sql5, sql6, sql7, sql8, sql9, sql10, sql11, sql12, sql13, sql14, sql15, sql16

